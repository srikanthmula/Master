package examples.pl.plugins.integration.inbound.jmsadapter;

import gw.plugin.integration.inbound.InboundIntegrationHandlerPlugin;
import org.osgi.service.component.annotations.Component;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

@Component(service = SampleJMSMessageListener.class)
public class SampleJMSMessageListener implements InboundIntegrationHandlerPlugin {
  private static final Logger log = LoggerFactory.getLogger(SampleJMSMessageListener.class);

  /* (non-Javadoc)
   * @see javax.jms.MessageListener#onMessage(javax.jms.Message)
   */
  @Override
  public void process(Object message) {
    log.info("{}.onMessage: {}", this, message);
  }

}
